using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyTitle("File Generator for Reflector")]
[assembly: AssemblyDescription("Contains an add-in that can generate source code for assemblies, modules, namespaces or individual types.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("jasonbock.net")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("2005")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]     
[assembly: AssemblyVersion("2.5.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: ReflectionPermission(SecurityAction.RequestMinimum, Unrestricted=true)]
