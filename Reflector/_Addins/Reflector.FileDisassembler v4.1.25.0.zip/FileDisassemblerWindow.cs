namespace Reflector.FileDisassembler
{
	using System;
	using System.Collections;
	using System.Drawing;
	using System.IO;
	using System.Windows.Forms;
	using Reflector.CodeModel;
	using Reflector.CodeModel.Memory;

	internal class FileDisassemblerWindow : UserControl
	{
		private Label outputDirectoryLabel = new Label();
		private TextBox outputDirectoryText = new TextBox();
		private TextBox logTextBox = new TextBox();
		private ProgressBar progressBar = new ProgressBar();
		private Button generateButton = new Button();
		
		private string outputDirectory = string.Empty;

		private IAssemblyBrowser assemblyBrowser;
		private IAssemblyLoader assemblyLoader;
		private ILanguageManager languageManager;
		private IVisitorManager visitorManager;
		
		public FileDisassemblerWindow()
		{
			this.Dock = DockStyle.Fill;

			this.outputDirectoryLabel.FlatStyle = FlatStyle.System;
			this.outputDirectoryLabel.Location = new Point(12, 12);
			this.outputDirectoryLabel.Name = "outputDirectoryLabel";
			this.outputDirectoryLabel.Size = new Size(88, 16);
			this.outputDirectoryLabel.TabIndex = 0;
			this.outputDirectoryLabel.Text = "&Output Directory:";

			this.outputDirectoryText.Location = new Point(12, 28);
			this.outputDirectoryText.Width = 400 - 80;
			this.outputDirectoryText.TabIndex = 1;
			this.outputDirectoryText.TextChanged += new EventHandler(this.OutputDirectoryText_TextChanged);

			this.generateButton.FlatStyle = FlatStyle.System;
			this.generateButton.Location = new Point(12 + 400 - 75, 28);
			this.generateButton.Size = new Size(75, 21);
			this.generateButton.TabIndex = 2;
			this.generateButton.Text = "&Generate";
			this.generateButton.Click += new System.EventHandler(this.GenerateButton_Click);

			this.logTextBox.Location = new Point(12, 28 + 32);
			this.logTextBox.Size = new Size(400, 200);
			this.logTextBox.MaxLength = 1024 * 1024 * 8;
			this.logTextBox.TabIndex = 3;
			this.logTextBox.ScrollBars = ScrollBars.Vertical;
			this.logTextBox.ReadOnly = true;
			this.logTextBox.Multiline = true;
			this.logTextBox.WordWrap = false;
			this.logTextBox.Visible = false;

			this.progressBar.Location = new Point(12, 28 + 32 + 8 + 200);
			this.progressBar.Size = new Size(400, 16);
			this.progressBar.TabStop = false;
			this.progressBar.Visible = false;

			this.Controls.Add(this.generateButton);
			this.Controls.Add(this.progressBar);
			this.Controls.Add(this.logTextBox);
			this.Controls.Add(this.outputDirectoryText);
			this.Controls.Add(this.outputDirectoryLabel);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				this.AssemblyBrowser = null;
				this.LanguageManager = null;
				this.VisitorManager = null;
				this.AssemblyLoader = null;
			}
		
			base.Dispose(disposing);	
		}

		public IAssemblyBrowser AssemblyBrowser 
		{
			get
			{
				return this.assemblyBrowser;	
			}
			
			set
			{
				if (this.assemblyBrowser != null)
				{
					this.assemblyBrowser.ActiveItemChanged -= new EventHandler(this.AssemblyBrowser_ActiveItemChanged);
				}

				this.assemblyBrowser = value;	

				if (this.assemblyBrowser != null)
				{
					this.assemblyBrowser.ActiveItemChanged += new EventHandler(this.AssemblyBrowser_ActiveItemChanged);
				}
			}
		}

		public ILanguageManager LanguageManager
		{
			get
			{
				return this.languageManager;	
			}
			
			set
			{
				this.languageManager = value;	
			}
		}

		public IVisitorManager VisitorManager
		{
			get
			{
				return this.visitorManager;	
			}
			
			set
			{
				this.visitorManager = value;	
			}
		}

		public IAssemblyLoader AssemblyLoader
		{
			get
			{
				return this.assemblyLoader;
			}
			
			set
			{
				this.assemblyLoader = value;				
			}	
		}

		protected override void OnSizeChanged(EventArgs e)
		{
			this.outputDirectoryText.Width = this.ClientSize.Width - 12 - 12 - 75 - 5;
			this.generateButton.Left = this.ClientSize.Width - 12 - 75;

			this.progressBar.Width = this.ClientSize.Width - 12 - 12;
			this.progressBar.Top = this.ClientSize.Height - 12 - this.progressBar.Height;

			this.logTextBox.Width = this.ClientSize.Width - 12 - 12;
			this.logTextBox.Height = this.progressBar.Top - this.logTextBox.Top - 8;
		
			base.OnSizeChanged(e);	
		}

		protected override void OnParentChanged(EventArgs e)
		{
			base.OnParentChanged(e);

			this.outputDirectoryText.Enabled = true;
			this.generateButton.Enabled = true;

			this.logTextBox.Visible = false;
			this.progressBar.Visible = false;

			this.AssemblyBrowser_ActiveItemChanged(this, EventArgs.Empty);
		}

		private void GenerateButton_Click(object sender, System.EventArgs e)
		{
			this.outputDirectoryText.Enabled = false;
			this.generateButton.Enabled = false;

			this.outputDirectory = Path.Combine(Environment.CurrentDirectory, Environment.ExpandEnvironmentVariables(this.outputDirectoryText.Text));

			if (!Directory.Exists(this.outputDirectory))
			{
				Directory.CreateDirectory(this.outputDirectory);
			}

			this.logTextBox.Text = string.Empty;
			this.logTextBox.Visible = true;
			this.progressBar.Value = 0;
			this.progressBar.Visible = true;

			IAssemblyResolver resolver = this.AssemblyLoader.Resolver;
			this.AssemblyLoader.Resolver = new AssemblyResolver(resolver);
			try
			{
				ILanguageConfiguration configuration = new LanguageConfiguration();
	
				IAssembly assembly = this.assemblyBrowser.ActiveItem as IAssembly;
				if (assembly != null)
				{
					int exceptions = 0;
					
					exceptions += this.WriteAssembly(assembly, configuration);
					
					foreach (IModule module in assembly.Modules)
					{
						for (int i = 0; i < module.Types.Count; i++)
						{
							ITypeDeclaration typeDeclaration = module.Types[i];
							if ((typeDeclaration.Namespace.Length != 0) || (typeDeclaration.Name != "<PrivateImplementationDetails>"))
							{
								exceptions += this.WriteTypeDeclaration(typeDeclaration, configuration);
							}
	
							this.progressBar.Value = (int) ((i * 100) / module.Types.Count);
						}					
					}
					
					foreach (IResource resource in assembly.Resources)
					{
						exceptions += this.WriteResource(resource);
					}
					
					this.WriteLine(string.Format("{0} error(s).", exceptions));
					this.WriteLine("Done.");
				}
			}
			finally
			{
				this.AssemblyLoader.Resolver = resolver;
			}

			this.progressBar.Value = 100;
			this.outputDirectoryText.Enabled = true;
			this.generateButton.Enabled = true;
		}

		private int WriteAssembly(IAssembly assembly, ILanguageConfiguration configuration)
		{
			ILanguage language = this.LanguageManager.ActiveLanguage;

			int exceptions = 0;
			
			using (StreamWriter streamWriter = this.CreateAssemblyFile(assembly))
			{
				TextFormatter formatter = new TextFormatter();
				try
				{
					ILanguageWriter writer = language.GetWriter(formatter, configuration);
					
					writer.WriteAssembly(assembly);
					
					foreach (IModule module in assembly.Modules)
					{
						writer.WriteModule(module);

						foreach (IAssemblyName assemblyName in module.AssemblyReferences)
						{
							writer.WriteAssemblyName(assemblyName);
						}

						foreach (IModuleName moduleName in module.ModuleReferences)
						{
							writer.WriteModuleName(moduleName);
						}
					}

					foreach (IResource resource in assembly.Resources)
					{
						writer.WriteResource(resource);	
					}
				}
				catch (Exception exception)
				{
					streamWriter.WriteLine(exception.ToString());	
					this.WriteLine(exception.ToString());
					exceptions++;
				}			

				string output = formatter.ToString().Replace("\r\n", "\n").Replace("\n", "\r\n");
				streamWriter.WriteLine(output);
			}
			
			return exceptions;
		}

		private StreamWriter CreateAssemblyFile(IAssembly assembly)
		{
			return this.CreateFile(string.Empty, "AssemblyInfo");
		}

		private int WriteTypeDeclaration(ITypeDeclaration typeDeclaration, ILanguageConfiguration configuration)
		{
			ILanguage language = this.LanguageManager.ActiveLanguage;
			IVisitor visitor = this.VisitorManager.ActiveVisitor;

			int excepctions = 0;

			using (StreamWriter streamWriter = this.CreateTypeDeclarationFile(typeDeclaration))
			{
				INamespace namespaceItem = new Namespace();
				namespaceItem.Name = typeDeclaration.Namespace;

				try
				{
					if (language.Name != "IL")
					{
						typeDeclaration = visitor.VisitTypeDeclaration(typeDeclaration);
					}

					namespaceItem.Types.Add(typeDeclaration);
				}
				catch (Exception exception)
				{
					streamWriter.WriteLine(exception.ToString());	
					this.WriteLine(exception.ToString());
					excepctions++;
				}

				TextFormatter formatter = new TextFormatter();
				ILanguageWriter writer = language.GetWriter(formatter, configuration);
				try
				{
					writer.WriteNamespace(namespaceItem);
				}
				catch (Exception exception)
				{
					streamWriter.WriteLine(exception.ToString());	
					this.WriteLine(exception.ToString());
					excepctions++;
				}

				string output = formatter.ToString().Replace("\r\n", "\n").Replace("\n", "\r\n");
				streamWriter.WriteLine(output);
			}
			
			return excepctions;
		}

		private StreamWriter CreateTypeDeclarationFile(ITypeDeclaration typeDeclaration)
		{
			string directory = typeDeclaration.Namespace.Replace(".", "\\");

			string fileName = typeDeclaration.Name;
			if (typeDeclaration.GenericArguments.Count > 0)
			{
				fileName = fileName + "!" +	typeDeclaration.GenericArguments.Count.ToString();
			}
	
			return this.CreateFile(directory, fileName);
		}

		private StreamWriter CreateFile(string directory, string fileName)
		{
			directory = directory.Replace("<", "_");
			directory = directory.Replace(">", "_");
			directory = directory.Replace(":", "_");
			directory = directory.Replace("|", "_");
			directory = directory.Replace("?", "_");
			directory = directory.Replace("*", "_");
			directory = Path.Combine(this.outputDirectory, directory);

			if (!Directory.Exists(directory))
			{
				Directory.CreateDirectory(directory);
			}

			ILanguage language = this.LanguageManager.ActiveLanguage;
			string fileExtension = language.FileExtension;

			fileName = fileName.Replace("<", "_");
			fileName = fileName.Replace(">", "_");
			fileName = fileName.Replace(":", "_");
			fileName = fileName.Replace("|", "_");
			fileName = fileName.Replace("?", "_");
			fileName = fileName.Replace("*", "_");
			fileName = Path.Combine(directory, fileName);
			fileName = Path.ChangeExtension(fileName, fileExtension);

			this.WriteLine(fileName);

			StreamWriter writer = new StreamWriter(fileName);
			return writer;
		}

		private int WriteResource(IResource resource)
		{
			byte[] buffer = null;

			IEmbeddedResource embeddedResource = resource as IEmbeddedResource;
			if (embeddedResource != null)
			{
				buffer = embeddedResource.Value;					
			}
			
			IFileResource fileResource = resource as IFileResource;
			if (fileResource != null)
			{
				string location = Path.Combine(Path.GetDirectoryName(fileResource.Module.Location), fileResource.Location);
				location = Environment.ExpandEnvironmentVariables(location);
				if (File.Exists(location))
				{
					using (Stream stream = new FileStream(location, FileMode.Open, FileAccess.Read))
					{
						if (fileResource.Offset == 0)
						{
							buffer = new byte[stream.Length];
							stream.Read(buffer, 0, buffer.Length);
						}
						else
						{
							BinaryReader reader = new BinaryReader(stream);
							int size = reader.ReadInt32();
							buffer = new byte[size];
							stream.Read(buffer, 0, size);
						}
					}
				}
			}

			if (buffer != null)
			{
				using (Stream stream = this.CreateResourceFile(resource))
				{
					stream.Write(buffer, 0, buffer.Length);
				}
			}
			
			return 0;
		}
		
		private Stream CreateResourceFile(IResource resource)
		{
			string fileName = Path.Combine(this.outputDirectory, resource.Name);
			this.WriteLine(fileName);
			return File.Create(fileName);
		}

		private void WriteLine(string text)
		{
			this.logTextBox.Focus();
			this.logTextBox.AppendText(text + "\r\n");
			this.logTextBox.ScrollToCaret();
			System.Windows.Forms.Application.DoEvents();
		}
		
		private void AssemblyBrowser_ActiveItemChanged(object sender, EventArgs e)
		{
			IAssembly assembly = this.assemblyBrowser.ActiveItem as IAssembly;
			if ((assembly != null) && (assembly.Location != null) && (assembly.Location.Length != 0))
			{
				this.outputDirectoryText.Text = Path.Combine(Path.GetDirectoryName(assembly.Location), "Source");
				this.outputDirectoryText.Enabled = true;
				this.generateButton.Enabled = true;
			}
			else
			{
				this.outputDirectoryText.Text = "<No assembly selected>";
				this.outputDirectoryText.Enabled = false;
				this.generateButton.Enabled = false;
			}			
		}

		private void OutputDirectoryText_TextChanged(object sender, EventArgs e)
		{
			this.generateButton.Enabled = ((this.outputDirectoryText.Text != null) && (this.outputDirectoryText.Text.Length != 0));
		}

		private class LanguageConfiguration : ILanguageConfiguration
		{
			private IVisibilityConfiguration visibility = new VisibilityConfiguration();

			public IVisibilityConfiguration Visibility
			{
				get
				{
					return this.visibility;
				}
			}

			public bool SortAlphabetically   { get { return true; } }
			public bool ShowCustomAttributes { get { return true; } }
			public bool ShowTypeMembers      { get { return true; } }
			public bool ShowMethodBodies     { get { return true; } }
			public bool ShowNamespaceTypes   { get { return true; } }
			public bool ShowNamespaceImports { get { return true; } }
		}

		private class VisibilityConfiguration : IVisibilityConfiguration
		{
			public bool Public            { get { return true; } }
			public bool Private           { get { return true; } }
			public bool Family            { get { return true; } }
			public bool Assembly          { get { return true; } }
			public bool FamilyAndAssembly { get { return true; } }
			public bool FamilyOrAssembly  { get { return true; } }
		}

		private class AssemblyResolver : IAssemblyResolver
		{
			private IDictionary assemblyTable;
			private IAssemblyResolver assemblyResolver;
	
			public AssemblyResolver(IAssemblyResolver assemblyResolver)
			{
				this.assemblyTable = new Hashtable();
				this.assemblyResolver = assemblyResolver;
			}
	
			public IAssembly Resolve(IAssemblyName assemblyName, string localPath)
			{
				if (this.assemblyTable.Contains(assemblyName))
				{
					return (IAssembly) this.assemblyTable[assemblyName];
				}
				
				IAssembly assembly = this.assemblyResolver.Resolve(assemblyName, localPath);
	
				this.assemblyTable.Add(assemblyName, assembly);
	
				return assembly;			
			}
		}
	}
}
