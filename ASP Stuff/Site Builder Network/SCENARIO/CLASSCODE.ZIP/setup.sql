/* Microsoft SQL Server - Scripting			*/
/* Server: SMUM002					*/
/* Database: Job					*/
/* Creation Date 4/5/98 9:32:56 AM 			*/

/****** Object:  Login usr_classified    Script Date: 4/5/98 9:45:09 AM ******/
if not exists (select * from master..syslogins where name = 'usr_classified')
BEGIN
	declare @logindb varchar(30), @loginlang varchar(30) select @logindb = 'job', @loginlang = null
	if @logindb is null or not exists (select * from master..sysdatabases where name = @logindb)
		select @logindb = 'master'
	if @loginlang is null or (not exists (select * from master..syslanguages where name = @loginlang) and @loginlang <> 'us_english')
		select @loginlang = @@language
	exec sp_addlogin 'usr_classified', null, @logindb, @loginlang
END
GO

/****** Object:  User usr_classified    Script Date: 4/5/98 9:45:09 AM ******/
if not exists (select * from sysusers where name = 'usr_classified' and uid < 16382)
	EXEC sp_adduser 'usr_classified', 'usr_classified', 'public'
GO

/****** Object:  Table dbo.Post    Script Date: 4/5/98 9:32:57 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Post') and sysstat & 0xf = 3)
	drop table dbo.Post
GO

/****** Object:  Table dbo.SubSection    Script Date: 4/5/98 9:32:57 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.SubSection') and sysstat & 0xf = 3)
	drop table dbo.SubSection
GO

/****** Object:  Table dbo.Region    Script Date: 4/5/98 9:32:57 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Region') and sysstat & 0xf = 3)
	drop table dbo.Region
GO

/****** Object:  Table dbo.Section    Script Date: 4/5/98 9:32:57 AM ******/
if exists (select * from sysobjects where id = object_id('dbo.Section') and sysstat & 0xf = 3)
	drop table dbo.Section
GO

/****** Object:  Table dbo.Region    Script Date: 4/5/98 9:32:57 AM ******/
CREATE TABLE dbo.Region (
	Region_Id int IDENTITY (1, 1) NOT NULL ,
	Region_Title varchar (100) NOT NULL ,
	Region_Date datetime NULL CONSTRAINT DF_Region_Region_Date_2__11 DEFAULT (getdate()),
	CONSTRAINT PK___1__11 PRIMARY KEY  CLUSTERED 
	(
		Region_Id
	)
)
GO

GRANT  REFERENCES ,  SELECT ,  INSERT ,  DELETE ,  UPDATE  ON Region  TO usr_classified
GO

/****** Object:  Table dbo.Section    Script Date: 4/5/98 9:32:58 AM ******/
CREATE TABLE dbo.Section (
	Section_Id int IDENTITY (1, 1) NOT NULL ,
	Section_Title int NOT NULL ,
	Section_SubTitle varchar (100) NOT NULL ,
	Section_Date datetime NULL CONSTRAINT DF_Section_Section_Date_3__11 DEFAULT (getdate()),
	CONSTRAINT PK___2__11 PRIMARY KEY  CLUSTERED 
	(
		Section_Id
	)
)
GO

GRANT  REFERENCES ,  SELECT ,  INSERT ,  DELETE ,  UPDATE  ON Section TO usr_classified
GO

/****** Object:  Table dbo.SubSection    Script Date: 4/5/98 9:32:58 AM ******/
CREATE TABLE dbo.SubSection (
	SubSection_Id int IDENTITY (1, 1) NOT NULL ,
	SubSection_Section_Id int NOT NULL ,
	SubSection_Title int NOT NULL ,
	SubSection_SubTitle varchar (100) NOT NULL ,
	SubSection_Date datetime NULL CONSTRAINT DF_SubSection_SubSection_5__11 DEFAULT (getdate()),
	CONSTRAINT PK___3__11 PRIMARY KEY  CLUSTERED 
	(
		SubSection_Id
	),
	CONSTRAINT FK___4__11 FOREIGN KEY 
	(
		SubSection_Section_Id
	) REFERENCES dbo.Section (
		Section_Id
	)
)
GO

GRANT  REFERENCES ,  SELECT ,  INSERT ,  DELETE ,  UPDATE  ON SubSection TO usr_classified
GO

/****** Object:  Table dbo.Post    Script Date: 4/5/98 9:32:58 AM ******/
CREATE TABLE dbo.Post (
	Post_Id int IDENTITY (1, 1) NOT NULL ,
	Post_Title varchar (100) NOT NULL ,
	Post_Text text NULL ,
	Post_Region_Id int NOT NULL ,
	Post_SubSection_Id int NOT NULL ,
	Post_Date datetime NULL CONSTRAINT DF_Post_Post_Date_1__12 DEFAULT (getdate()),
	Post_Company varchar (100) NULL ,
	Post_Address varchar (100) NULL ,
	Post_City varchar (40) NULL ,
	Post_State varchar (40) NULL ,
	Post_Country varchar (40) NULL ,
	Post_ZipCode varchar (20) NULL ,
	Post_Phone varchar (20) NULL ,
	Post_Email varchar (75) NULL ,
	Post_Contact varchar (100) NULL ,
	Post_Read int NULL CONSTRAINT DF_Post_Post_Read_1__13 DEFAULT (0),
	CONSTRAINT PK___4__11 PRIMARY KEY  CLUSTERED 
	(
		Post_Id
	),
	CONSTRAINT FK___5__11 FOREIGN KEY 
	(
		Post_Region_Id
	) REFERENCES dbo.Region (
		Region_Id
	),
	CONSTRAINT FK_Post_1__11 FOREIGN KEY 
	(
		Post_SubSection_Id
	) REFERENCES dbo.SubSection (
		SubSection_Id
	)
)
GO

GRANT  REFERENCES ,  SELECT ,  INSERT ,  DELETE ,  UPDATE  ON Post TO usr_classified
GO

INSERT INTO Region (Region_Title) VALUES ('US-Northeast')
INSERT INTO Region (Region_Title) VALUES ('US-Southeast')
INSERT INTO Region (Region_Title) VALUES ('Canada')
INSERT INTO Region (Region_Title) VALUES ('Mexico')
INSERT INTO Region (Region_Title) VALUES ('US-Southwest')
INSERT INTO Region (Region_Title) VALUES ('US-Northwest')
INSERT INTO Region (Region_Title) VALUES ('US-Midwest')
INSERT INTO Region (Region_Title) VALUES ('US-Great Lakes')
INSERT INTO Region (Region_Title) VALUES ('Australia')
INSERT INTO Region (Region_Title) VALUES ('South America')
INSERT INTO Region (Region_Title) VALUES ('Africa')
INSERT INTO Region (Region_Title) VALUES ('Asia')
INSERT INTO Region (Region_Title) VALUES ('Europe')

GO

INSERT INTO Section (Section_Title,Section_SubTitle) VALUES (100,'General')

GO

INSERT INTO SubSection (SubSection_Section_Id,SubSection_Title,SubSection_SubTitle) VALUES (@@IDENTITY,101,'Free')

GO
